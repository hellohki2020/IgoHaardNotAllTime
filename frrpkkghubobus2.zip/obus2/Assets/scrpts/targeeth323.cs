﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class targeeth323 : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void OnTriggerEnter2D(Collider2D other)
    {
        if (other.tag =="bllet232")
        {
            Debug.Log("moim");
            Destroy(gameObject);

        }

    }
    void OnCollisionEnter(Collision collision)
    {
        if (collision.collider.tag == "bllet232")
        {
            Destroy(gameObject);
            //if(collision.gameObject.name == "GameObject")
            Debug.Log("oncol");
        }
    }
}
