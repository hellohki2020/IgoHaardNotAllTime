﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FockerIsOntheRun : MonoBehaviour
{
    public float speed2;
    public float angle;


    //not yeet2plyaersas

    private float RotateSpeed = 5f;
    private float Radius = 10.1f;

    private Vector2 _centre;
    private float _angle;


    // Start is called before the first frame update
    void Start()
    {
        _centre = transform.position;
    }

    // Update is called once per fram
    void Update()
    {


        //Vector3 direction = player.position - enemy.position;

        //enemy.forward = direction;
        //if (direction.magnitude < distance) { enemy.position += enemy.right * speed; }
        //else { enemy.position += enemy.forward * speed; }


        //oldies. minitunes. the dogs kids like to ... *sigh*
        //
        //gameObject.transform.position = new Vector2(transform.position.x + (1 * speed2), transform.position.y + 1 * speed2);

        //timer += Time.deltaTime;
        //angle = timer;
        //this.transform.position = new Vector3((centerx + Mathf.Sin(angle) * rad), centery, ((centerz + Mathf.Cos(angle) * rad)));

        //currentRotation += 2 * Time.deltaTime * 100;
        //rotation.eulerAngles = Vector3(0, currentRotation, 0);
       // transform.position = rotation * radius;


        _angle += RotateSpeed * Time.deltaTime;

        var offset = new Vector2(Mathf.Sin(_angle), Mathf.Cos(_angle)) * Radius;
        transform.position = _centre + offset;

        //i admire your "coding"

        //armour low floops



    }
}
