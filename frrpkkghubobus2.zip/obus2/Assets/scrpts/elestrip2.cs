﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class elestrip2 : MonoBehaviour
{

    public GameObject geeli;
    //public Rigibody2D apina;
    public float spiidi2 = 15;
    public Transform targeeth2322;
    Vector3 myscreenPos;

    public float bulletVelocity = 20f;
    public GameObject bullet;
    public GameObject bullet1;

    Vector3 moveDirection;


    public GameObject crosshairs;
    public GameObject player;
    public GameObject bulletPrefab;
    public GameObject bulletStart;

    public float bulletSpeed = 60.0f;

    private Vector3 target;

    // Start is called before the first frame update
    void Start()
    {
        //myscreenPos = Camera.main.WorldToScreenPoint(this.transform.position);
        // moveDirection = (Camera.main.ScreenToWorldPoint(Input.mousePosition) - transform.position);
        //moveDirection.z = 0;
        //moveDirection.Normalize();



    }

    // Update is called once per frame
    void Update()
        //targeeth2322 = Camera.main.ScreenToWorldPoint(Input.MousePosition);
    {
       
         
         


         if (Input.GetButtonDown("Fire1"))
         {
             Vector3 worldMousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
             Vector2 direction = (Vector2)((worldMousePos - transform.position));
             direction.Normalize();
             // Creates the bullet locally
             GameObject bullet = (GameObject)Instantiate(
                                     bullet1,
                                     transform.position + (Vector3)(direction),
                                     Quaternion.identity);
             // Adds velocity to the bullet
             bullet.GetComponent<Rigidbody2D>().velocity = direction * bulletVelocity;
         }


   

    }



}

